#!/usr/bin/env python3

import time
import os
import sys

if __name__ == '__main__':
    print("Starting script...")

    start = int(sys.argv[1])
    #max = int(sys.argv[2])
    max = int(os.environ.get("MAXNUM"))

    print("Param start num: "+str(start))
    print("Env MAXNUM: "+str(max))

    for n in range(start,max):
        print("N: "+str(n))
        time.sleep(1)

    print("Ending script!");

