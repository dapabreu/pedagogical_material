#!/usr/bin/env python3

import time

if __name__ == '__main__':
    print("Starting script...")
    
    for n in range(1,100):
        print("N: "+str(n))
        time.sleep(1)
    
    print("Ending script!")

