import logging
import time
from logstash_async_handler import AsynchronousLogStashHandler

host = 'localhost'
port = 5000

logger = logging.getLogger('python-logger')
logger.setLevel(logging.DEBUG)

asyncHandler = AsynchronousLogStashHandler(host, port, database_path = None)

logger.addHandler(asyncHandler)

while True:
    logger.info("This is an info message at %s", time.time)
    time.slee(30)