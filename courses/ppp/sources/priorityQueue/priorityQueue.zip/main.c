#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "myQueue.h"

#define numElements 10

int main(){
    typeQueue *simpleQueueptr;
    struct myItem qelement;
    time_t t;

    //Creating the queue
    simpleQueueptr = (typeQueue *) malloc(sizeof(typeQueue));

    //Verifying malloc
    if (simpleQueueptr == NULL){
        printf("Memory not allocated on simpleQueueptr.\n");
        return -1;
    }

    createQueue(simpleQueueptr);

    //Add some elements to the queue
    srand((unsigned) time(&t)); //Initializing the seed for the random

    for (int i=0; i<numElements; i++){
        qelement.priority = rand() % 5;
        qelement.data = i;
        addItemPriority(simpleQueueptr, qelement);
    }

    //Print the queue before destroy it
    printQueue(simpleQueueptr);
    destroyQueue(simpleQueueptr);
    free(simpleQueueptr);

    return 0;
}


