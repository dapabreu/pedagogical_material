//
// Created by david on 09/04/2023.
//

#include <stdio.h>
#include <stdlib.h>
#include "myQueue.h"

void createQueue (typeQueue *queue){
    queue->first = NULL;
    queue->last = NULL;
}

int emptyQueue(typeQueue *queue){
    if(queue->first == NULL)
        return 1;
    else
        return 0;
}

void destroyQueue(typeQueue *queue){
    itemQueue *temp_ptr;
    while(!emptyQueue(queue)){
        temp_ptr = queue->first;
        queue->first = queue->first->next;
        free(temp_ptr);
    }
    queue->last = NULL;
}

void addItem(typeQueue *queue, struct myItem item){
    itemQueue *temp_ptr;
    temp_ptr = (itemQueue *) malloc(sizeof(itemQueue));
    if(temp_ptr != NULL){
        temp_ptr->myItemQueue = item;
        temp_ptr->next = NULL;
        if(emptyQueue(queue))
            queue->first = temp_ptr;
        else
            queue->last->next = temp_ptr;
        queue->last = temp_ptr;
    }
}

void addItemPriority(typeQueue *queue, struct myItem item){
    itemQueue *temp_ptr;
    itemQueue *current;
    temp_ptr = (itemQueue *) malloc(sizeof(itemQueue));
    if(temp_ptr != NULL){
        temp_ptr->myItemQueue = item;
        temp_ptr->next = NULL;
        if(emptyQueue(queue)) {
            queue->first = temp_ptr;
            queue->last = temp_ptr;
        }else{
            current = queue->first;
            if (current->myItemQueue.priority > temp_ptr->myItemQueue.priority){
                temp_ptr->next = queue->first;
                queue->first = temp_ptr;
            }else{
                while (current->next != NULL && (current->next->myItemQueue.priority < temp_ptr->myItemQueue.priority)){
                    current = current->next;
                }
                temp_ptr->next = current->next;
                current->next = temp_ptr;
                if (current->next == NULL)
                    queue->last = temp_ptr;
            }
        }
    }
}

struct myItem removeItem(typeQueue *queue){
    itemQueue *temp_ptr;
    struct myItem item = {-1, -1};
    if(!emptyQueue(queue)){
        temp_ptr = queue->first;
        item = temp_ptr->myItemQueue;
        queue->first = queue->first->next;
        if(emptyQueue(queue))
            queue->last = NULL;
        free(temp_ptr);
        return (item);
    }
    return (item);

}

struct myItem peekQueue(typeQueue *queue){
    struct myItem item = {-1, -1};
    if(!emptyQueue(queue)){
        return(queue->first->myItemQueue);
    }
    else{
        return(item);
    }
}

struct myItem peekLastQueue(typeQueue *queue){
    struct myItem item = {-1, -1};
    if(!emptyQueue(queue)){
        return(queue->last->myItemQueue);
    }
    else{
        return(item);
    }
}

void printQueue(typeQueue *queue){
    itemQueue *current = queue->first;
    int i = 0;

    if (current != NULL){
        printf("+++++\n");
        while (current != NULL) {
            printf("Item: %d -- Priority: %d -- Data: %d\n", i, current->myItemQueue.priority,
                   current->myItemQueue.data);
            printf("+++++\n");
            current = current->next;
            i++;
        }
    }else{
        printf("The Queue is empty!\n");
    }
}
