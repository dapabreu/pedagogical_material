//
// Created by david on 09/04/2023.
//

#ifndef PRIORITYQUEUE_MYQUEUE_H
#define PRIORITYQUEUE_MYQUEUE_H

struct myItem{
    int data;
    int priority;
};

typedef struct itemQueue{
    struct myItem myItemQueue;
    struct itemQueue *next;
} itemQueue;

typedef struct typeQueue{
    itemQueue *first;
    itemQueue *last;
} typeQueue;

void createQueue(typeQueue *queue);
int emptyQueue(typeQueue *queue);
void destroyQueue(typeQueue *queue);
void addItem(typeQueue *queue, struct myItem item);
void addItemPriority(typeQueue *queue, struct myItem item);
struct myItem removeItem(typeQueue *queue);
struct myItem peekQueue(typeQueue *queue);
struct myItem peekLastQueue(typeQueue *queue);
void printQueue(typeQueue *queue);

#endif //PRIORITYQUEUE_MYQUEUE_H
